

/**
 *
 * @author Ivan Caballero <ivan.caballer at gmail.com>
 */
public class costoPersonal {

}
